#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd 
import numpy as np
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
#get_ipython().run_line_magic('matplotlib', 'inline')


# ## 参考资料
# 
# - 文字资料: https://towardsdatascience.com/pca-using-python-scikit-learn-e653f8989e60
# - 代码资料: https://github.com/mGalarnyk/Python_Tutorials/blob/master/Sklearn/PCA/PCA_Data_Visualization_Iris_Dataset_Blog.ipynb
# - sklearn PCA使用指南: https://scikit-learn.org/stable/modules/generated/sklearn.decomposition.PCA.html#sklearn.decomposition.PCA

# ## 读取数据

# In[2]:


df = pd.read_csv('./iris.csv', names=['sepal length','sepal width','petal length','petal width','target'])
df.head()


# In[52]:


df.shape


# ## 数据标准化
# 
# - PCA is effected by scale so you need to scale the features in your data before applying PCA.(PCA会被数据的大小所影响, 所以在做之前, 我们需要先对数据进行标准化)
# - 我们使用StandardScaler进行标准化, 标准化之后变为均值为0, 方差为1的数据

# In[3]:


features = ['sepal length', 'sepal width', 'petal length', 'petal width']
# Separating out the features
x = df.loc[:, features].values
# Separating out the target
y = df.loc[:,['target']].values
# Standardizing the features
x = StandardScaler().fit_transform(x)


# In[4]:


# 查看标准化之后的数据
pd.DataFrame(data = x, columns = features).head()


# ## 查看降维后的维数
# 
# - 选择降到多少维度比较合适

# In[41]:


pca = PCA(n_components=4)
principalComponents = pca.fit_transform(x)


# In[42]:


pca.explained_variance_ratio_


# In[43]:


# 进行可视化
importance = pca.explained_variance_ratio_
plt.scatter(range(1,5),importance)
plt.plot(range(1,5),importance)
plt.title('Scree Plot')
plt.xlabel('Factors')
plt.ylabel('Eigenvalue')
plt.grid()
plt.show()


# ## 使用PCA降维(降维到2维)
# 
# - 降维到2维可以方便进行可视化

# In[44]:


pca = PCA(n_components=2)


# In[45]:


principalComponents = pca.fit_transform(x)


# In[46]:


# 降维后的新数据
principalDf = pd.DataFrame(data=principalComponents, columns=['principal component 1', 'principal component 2'])
finalDf = pd.concat([principalDf, df[['target']]], axis = 1)
finalDf.head(5)


# In[47]:


pca.explained_variance_ratio_


# In[48]:


pca.explained_variance_ 


# ## 得到转换的关系(系数)

# In[49]:


pca.components_


# $PCA_1 = 0.52237162*x_1 + -0.26335492*x_2 + 0.58125401*x_3 + 0.56561105*x_4$

# In[50]:


# 这个计算的值就是上面生成的值, 这个相当于是系数
(np.dot(x[0],pca.components_[0]), np.dot(x[0],pca.components_[1]))


# In[51]:


# 对系数进行可视化
import seaborn as sns

df_cm = pd.DataFrame(np.abs(pca.components_), columns=df.columns[:-1])
plt.figure(figsize = (12,6))
ax = sns.heatmap(df_cm, annot=True, cmap="BuPu")
# 设置y轴的字体的大小
ax.yaxis.set_tick_params(labelsize=15)
ax.xaxis.set_tick_params(labelsize=15)
plt.title('PCA', fontsize='xx-large')
# Set y-axis label
plt.savefig('factorAnalysis.png', dpi=200)


# ## 进行可视化

# In[11]:


fig = plt.figure(figsize = (8,8))
ax = fig.add_subplot(1,1,1) 
ax.set_xlabel('Principal Component 1', fontsize = 15)
ax.set_ylabel('Principal Component 2', fontsize = 15)
ax.set_title('2 Component PCA', fontsize = 20)


targets = ['Iris-setosa', 'Iris-versicolor', 'Iris-virginica']
colors = ['r', 'g', 'b']
for target, color in zip(targets,colors):
    indicesToKeep = finalDf['target'] == target
    # 选择某个label下的数据进行绘制
    ax.scatter(finalDf.loc[indicesToKeep, 'principal component 1']
               , finalDf.loc[indicesToKeep, 'principal component 2']
               , c = color
               , s = 50)
ax.legend(targets)
ax.grid()


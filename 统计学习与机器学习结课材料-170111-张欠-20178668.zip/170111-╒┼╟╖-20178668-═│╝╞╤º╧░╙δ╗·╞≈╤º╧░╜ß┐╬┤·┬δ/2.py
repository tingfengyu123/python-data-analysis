# -*- coding: utf-8 -*-
from numpy import *
import logRegres

# 逻辑回归梯度上升优化算法
dataArr,labelMat= logRegres.loadDataSet()
print(logRegres.gradAscent(dataArr, labelMat))

# 画出数据集和Logistic回归最佳拟合直线的函数
weights=logRegres.gradAscent(dataArr,labelMat)
logRegres.plotBestFit((weights.getA()))

# 随机梯度上升法
weights=logRegres.stocGradAscent0(array(dataArr),labelMat)
logRegres.plotBestFit((weights))

# 改进的随机梯度上升算法
weights=logRegres.stocGradAscent1(array(dataArr),labelMat)
logRegres.plotBestFit((weights))

# logistic回归分类函数
logRegres.multiTest()

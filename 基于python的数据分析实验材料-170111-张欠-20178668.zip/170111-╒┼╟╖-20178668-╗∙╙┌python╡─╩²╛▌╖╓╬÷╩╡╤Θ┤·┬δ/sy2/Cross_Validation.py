# -*- coding: utf-8 -*-

import numpy as np
from sklearn.model_selection import KFold
from PCA import PCA

class Cross_Validation():
    def __init__(self, x, y, n_folds, max_components):
        self.x = x
        self.y = y
        self.n_folds = n_folds
        self.max_components = max_components
        self.n = x.shape[0]
        
    def cv(self):
        kf = KFold(self.n_folds, shuffle=False)
        x_train = []
        x_test = []
        y_train = []
        y_test = []
        for train_index, test_index in kf.split(self.x,self.y):
            xtr, xte = self.x[train_index], self.x[test_index]
            ytr, yte = self.y[train_index], self.y[test_index]
            x_train.append(xtr)
            x_test.append(xte)
            y_train.append(ytr)
            y_test.append(yte)
            
        return x_train, x_test, y_train, y_test
    
    def predict_cv(self):
        x_train, x_test, y_train, y_test = self.cv()
        y_allPredict = np.ones((1, self.max_components))
        B = []
        
        for i in range(self.n_folds):
            
            y_predict = np.zeros((y_test[i].shape[0], self.max_components))
            x_train_mean = np.mean(x_train[i], axis=0)
            y_train_mean = np.mean(y_train[i], axis=0)
            x_testCenter = np.subtract(x_test[i], x_train_mean)
            
            for j in range(self.max_components):
                pca = PCA(n_components=j+1)
                T, P = pca.fit_transform(x_train[i])
                B = self.fit(T, y_train[i])
                
                y_pre = np.dot(np.dot(x_testCenter, P), B)
                y_pre = y_pre + y_train_mean
                y_predict[:, j] = y_pre.ravel()
      
            y_allPredict = np.vstack((y_allPredict, y_predict))
        y_allPredict = y_allPredict[1:]
        
        return y_allPredict, self.y
    
    def fit(self, T, Y):  # 姹� 鍘熺郴鏁�
        Y_mean = np.mean(Y, axis=0)
        y_cen = np.subtract(Y, Y_mean)
        coefs = np.linalg.lstsq(T, y_cen)[0]

        return coefs
    
    def mse_cv(self, y_allPredict, y_measure):
        press = np.square(np.subtract(y_allPredict, y_measure))
        press_all = np.sum(press, axis=0)
        RMSECV = np.sqrt(press_all / self.n)
        min_RMSECV = min(RMSECV)
        comp_array = RMSECV.argsort()
        comp_best = comp_array[0] + 1
        
        return RMSECV, min_RMSECV, comp_best


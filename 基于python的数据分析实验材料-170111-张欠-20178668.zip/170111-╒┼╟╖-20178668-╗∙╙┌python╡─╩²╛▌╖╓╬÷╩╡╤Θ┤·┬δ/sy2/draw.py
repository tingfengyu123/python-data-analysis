# -*- coding: utf-8 -*-
import matplotlib.pyplot as plt

def rmsecv_comp_line_pharm(max_components, rmsecv_list):
    plt.figure(figsize=(4, 4), facecolor='white')
    #plt.title('oil')
    #plt.title('pro')
    #plt.title('starch')
    plt.title('moisture')
    plt.plot(range(1, max_components + 1), rmsecv_list, '-o')
    plt.xlabel('The number of latent variable protein')
    plt.ylabel('RMSECV')

    plt.tight_layout()
    plt.show()

def draws_pre_pharm(Y_test, Y_predict, y_trainPredict, y_train):
    plt.figure(figsize=(4, 4), facecolor='white')

    #plt.title('oil')
    #plt.title('pro')
    #plt.title('starch')
    plt.title('moisture')
    plt.plot([min(y_train), max(y_train)], [min(y_train), max(y_train)], 'black', label='y=x')
    plt.scatter(y_train, y_trainPredict, s=60, c='r', marker='o', label='calibration set')
    plt.xlabel('Measured value')
    plt.ylabel(' Predicted value')

    plt.tight_layout()
    plt.show()

# -*- coding: utf-8 -*-

from Cross_Validation import Cross_Validation
import numpy as np
from sklearn.model_selection import train_test_split
from PCA import PCA
from scipy.io.matlab.mio import loadmat
from draw import rmsecv_comp_line_pharm,draws_pre_pharm

class PCR():
    def __init__(self, n_folds=10, max_components=5):
        self.n_folds = n_folds
        self.max_components = max_components

    def fit(self, X, y, comp_best):

        self.x_mean = np.mean(X, axis=0)
        self.y_mean = np.mean(y, axis=0)
        
        pca = PCA(n_components=comp_best)
        T, P = pca.fit_transform(np.subtract(X, self.x_mean))

        y_center = np.subtract(y, self.y_mean)
        coefs_B = np.linalg.lstsq(T, y_center)[0]  
        
        return coefs_B, P
    
    def cv_choose_param(self, X, y):
        
        pcr_cv = Cross_Validation(X, y, self.n_folds, self.max_components)
        y_allPredict, y_measure = pcr_cv.predict_cv()
        RMSECV, min_RMSECV, comp_best = pcr_cv.mse_cv(y_allPredict, y_measure)
      
        return RMSECV, min_RMSECV, comp_best
        
    def predict(self, X, y, coefs_B, P):
        
        T = np.dot(np.subtract(X, self.x_mean), P)

        y_pre = np.dot(T, coefs_B)
        y_predict = np.add(y_pre, self.y_mean)         
        
        press = np.square(np.subtract(y, y_predict))
        all_press = np.sum(press, axis=0)
        RMSEP = np.sqrt(all_press / X.shape[0])

        return y_predict, RMSEP
        

if __name__ == '__main__':
   
    D = loadmat('cornmat.mat')
    #y = D['oil'][:, 0:1]
    #y = D['pro'][:, 0:1]
    #y = D['starch'][:, 0:1]
    y = D['water'][:, 0:1]
    #x = D['m5']
    #x = D['mp5']
    x = D['mp6']

    x_cal,x_test,y_cal,y_test = train_test_split(x,y,test_size=0.2, random_state=0)
         
    pcr = PCR(n_folds=10, max_components=15)      
    RMSECV, min_RMSECV, comp_best = pcr.cv_choose_param(x_cal, y_cal)
    coefs_cal, P_m_cal = pcr.fit(x_cal, y_cal,comp_best)   
    y_cal_predict, RMSEC = pcr.predict(x_cal, y_cal, coefs_cal, P_m_cal)
    y_test_predict, RMSEP = pcr.predict(x_test, y_test, coefs_cal, P_m_cal)
    print('RMSECV:', RMSECV)
    print('RMSEP:', RMSEP)
    print('min_RMSECV:', min_RMSECV)
    print('comp_best:', comp_best)
    fig1 = rmsecv_comp_line_pharm(15, RMSECV)
    fig2 = draws_pre_pharm(y_test, y_test_predict, y_cal_predict, y_cal)

from sklearn.model_selection import train_test_split
from scipy.io.matlab.mio import loadmat
from PLS import PLS
import show

if __name__ == '__main__':
    fname = loadmat('NIRcorn.mat')
    x = fname['cornspect']
    y = fname['cornprop'][:, 0:1]
    print(x.shape, y.shape)
    x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.2, random_state=0)
    demo = PLS(x_train, y_train, x_test, y_test, n_fold=10, max_components=9)
    RMSECV, min_RMSECV, comp_best, RMSEC, RMSEP, y_predict, y_trainPredict = demo.pls()
    print('RMSECV', RMSECV)
    print('min_RMSECV', min_RMSECV)
    print('comp_best', comp_best)
    print('RMSEP:', RMSEP)
    show.draws_pre_pharm(y_test, y_predict, y_trainPredict, y_train)
    show.rmsecv_comp_line_pharm(9, RMSECV)
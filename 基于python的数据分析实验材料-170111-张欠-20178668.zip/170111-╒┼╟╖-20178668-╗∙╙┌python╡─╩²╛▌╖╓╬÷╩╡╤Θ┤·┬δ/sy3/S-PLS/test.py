# -*- coding:utf-8 -*-
 
from scipy.io import loadmat
from sklearn.model_selection import train_test_split
from Stack_pls import Stack_pls
from draw import rmsecv_comp_line_pharm,draws_pre_pharm
 
if __name__ == '__main__':

    fname = loadmat('cornmat.mat')
    x = fname['mp6']
    y = fname['water'][:, 0:1]

    x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.2, 
                                                        random_state=0)
    demo = Stack_pls(x_train, x_test, y_train, y_test, components=15, folds=5)
    RMSEP, y_predict, y_trainpredict, RMSECV= demo.stackPls(start=2, end=12,
                                                             intervals=2)
    print('RMSEP：', RMSEP)
    fig1 = rmsecv_comp_line_pharm(15, 12, RMSECV)
    fig2 = draws_pre_pharm(y_test, y_predict, y_trainpredict, y_train)
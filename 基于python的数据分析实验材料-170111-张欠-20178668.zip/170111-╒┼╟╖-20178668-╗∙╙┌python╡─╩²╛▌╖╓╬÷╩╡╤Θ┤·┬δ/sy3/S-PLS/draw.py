import matplotlib.pyplot as plt
import numpy as np
from mpl_toolkits.mplot3d import Axes3D
from matplotlib import cm

def rmsecv_comp_line_pharm(max_components, intervals, rmsecv):
    fig = plt.figure(figsize=(4, 4), facecolor='white')
    ax = fig.add_subplot(111, projection='3d')
    x = np.arange(1, max_components + 1, 1)
    y = np.arange(2, intervals, 2)
    X, Y = np.meshgrid(x, y)
    Z = rmsecv.T
    ax.plot_wireframe(X, Y, Z)
    ax.set_title('moisture')
    ax.set_xlabel('components')
    ax.set_ylabel('intervals')
    ax.set_zlabel('RMSECV')


    plt.tight_layout()
    plt.show()


def draws_pre_pharm(Y_test, Y_predict, y_trainPredict, y_train):
    plt.figure(figsize=(4, 4), facecolor='white')

    plt.title('moisture')
    plt.plot([min(y_train), max(y_train)], [min(y_train), max(y_train)], 'black', label='y=x')
    plt.scatter(y_train, y_trainPredict, s=60, c='r', marker='o', label='calibration set')
    plt.scatter(Y_test, Y_predict, s=90, c='b', marker='o', label='test set')
    plt.xlabel('Measured value')
    plt.ylabel(' Predicted value')

    plt.tight_layout()
    plt.show()
